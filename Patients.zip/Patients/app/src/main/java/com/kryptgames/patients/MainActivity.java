package com.kryptgames.patients;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText patientName;
    EditText patientAge;
    Spinner spinner;
    Button addPatient;
    TextView textView;
    ListView listViewPatients;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        patientName = findViewById(R.id.patientName);
        patientAge = findViewById(R.id.patientAge);
        spinner = findViewById(R.id.spinner);
        addPatient = findViewById(R.id.addPatient);
        textView = findViewById(R.id.textView);

        listViewPatients = findViewById(R.id.listViewPatients);


    }
}
